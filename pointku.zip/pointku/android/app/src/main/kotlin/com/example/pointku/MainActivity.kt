package com.example.pointku

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
