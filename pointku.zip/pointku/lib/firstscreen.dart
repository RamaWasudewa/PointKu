import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'scan.dart';

void main() => runApp(HomePage());

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PointKu',
      debugShowCheckedModeBanner: false,
      home: FirstScreen(),
    );
  }
}

class FirstScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Image(
            image: AssetImage("assets/Logo_Pointku.png"),
            height: 5.0,
            width: 5.0,
          ),
        ),
        title: Center(
          child: Text(
            'PointKu',
            textAlign: TextAlign.center,
          ),
        ),
        actions: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 15),
            child: IconButton(
              icon: new Icon(Icons.account_circle),
              onPressed: () {},
            ),
          )
        ],
      ),
      body: Column(
        children: [
          Container(
            child: new Card(
              color: Colors.lightBlue[50],
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: [
                  ListTile(
                    // trailing: Image(
                    //   image: AssetImage("assets/qr_code.png"),
                    //   height: 50.0,
                    //   width: 50.0,
                    // ),
                    title: const Text(
                      'Total SKP',
                      style:
                          TextStyle(fontWeight: FontWeight.w900, fontSize: 27),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        new Text(
                          '50/100',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 2.0),
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.only(left: 20),
                          child: Column(
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  new LinearPercentIndicator(
                                    width: 200.0,
                                    lineHeight: 14.0,
                                    percent: 0.5,
                                    center: Text(
                                      "50 Point",
                                      style: new TextStyle(fontSize: 12.0),
                                    ),
                                    leading:
                                        Icon(Icons.control_point_duplicate),
                                    linearStrokeCap: LinearStrokeCap.roundAll,
                                    backgroundColor: Colors.grey,
                                    progressColor: Colors.blue,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => Scan()),
                                      );
                                    },
                                    child: Container(
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 60.0),
                                            child: Image(
                                              image: AssetImage(
                                                  "assets/qr_code.png"),
                                              height: 50.0,
                                              width: 50.0,
                                            ),
                                          ),
                                          Row(
                                            children: [
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 61.0),
                                                child: Text(
                                                  "Scan",
                                                  style: TextStyle(
                                                      color: Colors.black,
                                                      fontWeight:
                                                          FontWeight.w800),
                                                  textAlign: TextAlign.center,
                                                ),
                                              )
                                            ],
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  ButtonBar(
                    alignment: MainAxisAlignment.start,
                    children: [
                      FlatButton(
                        textColor: Colors.grey,
                        onPressed: () {
                          // Perform some action
                        },
                        child: const Text('Tap for History'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
